import React, {  } from 'react';
import mainImage from '../Images/home-page-picture.jpg'
import '../CSS/style.css';
import '../CSS/index.css';
import TypedEffect from "./TypedEffect";


function Home() {

    return (
        <>
            <div className="container-fluid py-5 first-one">
                <div className="row">
                    <div className="col-md-6 image-className">
                        <div className="flashcard">
                            <img src={mainImage} alt="Left Flashcard Image" className="welcome-image" />
                        </div>
                    </div>
                    <div className="col-md-6 text-center welcome-header-className">
                        <section id="introduction">
                            <div className="introduction-container">
                                <div className="introduction-content">
                                    <div className="hello-container">
                                        <h4><TypedEffect /></h4>
                                    </div>
                                    <h1 className="welcome-h1">Welcome to JOT Foods</h1>
                                    <p className="lead welcome-p">Where Culture Meets Food</p>
                                    <div className="button">
                                        <a href="/Menu" className="btn btn-primary order-button">Order Now</a>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </>

    );
}

export default Home;